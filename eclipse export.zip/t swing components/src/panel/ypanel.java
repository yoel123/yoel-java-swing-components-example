package panel;

import java.awt.Color;

import javax.swing.JPanel;

public class ypanel extends JPanel 
{

	public ypanel() {
		super();
		setSize( 300, 300 );
		setBackground(Color.BLUE);
	}


}//end ypanel
